from django.apps import AppConfig


class IsoappConfig(AppConfig):
    name = 'isoapp'
